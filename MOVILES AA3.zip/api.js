const dbocategoria = require('./dbcategoria');
//Requerido en todos
var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');

var app = express();
var router = express.Router();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use('/api', router); //Ruta principal

//Ruta para todas las categorias
router.route('/categoria').get((request, response) => {
    dbocategoria.getCategoria().then(result => {
        //console.log(result);
        response.json(result[0]);
    })
})


var port = process.env.PORT || 8090; //Declarando puerto de inicio
app.listen(port); //Puerto de escucha
console.log('Categoria API Iniciado en el puerto : ' + port); //Mensaje de inicio de servicio