var config = require('./dbconfig'); //Instanciamos el archivo dbconfig
const sql = require('mssql'); //Se necesita paquete mssql

//Funcion Async : Asyncrona esta devuelve un objeto

async function getCategoria() {
    try {
        let pool = await sql.connect(config);
        let categorias = await pool.request().query("SELECT * FROM TM_CATEGORIA");
        return categorias.recordsets;
    } catch (error) {
        console.log(error);
    }
}

module.exports = {
    getCategoria: getCategoria
}