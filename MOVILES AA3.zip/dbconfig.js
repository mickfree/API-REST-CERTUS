const config = {
    user: 'sa',
    password: 'mecatronica11',
    server: 'DESKTOP-5PAONAF',
    database: 'BDTEST2',
    options: {
        trustedconnection: false,
        enableArithAbort: true,
        encrypt: false
            //instancename :'/'  En caso se tenga alguna instancia
    }
}

module.exports = config;